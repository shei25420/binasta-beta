<script setup>
import { Link } from '@inertiajs/inertia-vue3';
</script>

<template>
    <footer class="main">
        <section class="newsletter mb-15 wow animate__ animate__fadeIn animated"
            style="visibility: visible; animation-name: fadeIn;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="position-relative newsletter-inner">
                            <div class="newsletter-content">
                                <h2 class="mb-20">
                                    Stay home &amp; get your daily <br>
                                    needs from our shop
                                </h2>
                                <p class="mb-45">Start You'r Daily Shopping with <span class="text-brand">Nest
                                        Mart</span></p>
                                <form class="form-subcriber d-flex">
                                    <input type="email" placeholder="Your emaill address">
                                    <button class="btn" type="submit">Subscribe</button>
                                </form>
                            </div>
                            <img src="../../../assets/shop/imgs/banner/banner-9.png" alt="newsletter">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="featured section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6 mb-md-4 mb-xl-0">
                        <div class="banner-left-icon d-flex align-items-center wow animate__ animate__fadeInUp animated"
                            data-wow-delay="0" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-1.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Best prices &amp; offers</h3>
                                <p>Orders $50 or more</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__ animate__fadeInUp animated"
                            data-wow-delay=".1s"
                            style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-2.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Free delivery</h3>
                                <p>24/7 amazing services</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__ animate__fadeInUp animated"
                            data-wow-delay=".2s"
                            style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-3.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Great daily deal</h3>
                                <p>When you sign up</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__ animate__fadeInUp animated"
                            data-wow-delay=".3s"
                            style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-4.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Wide assortment</h3>
                                <p>Mega Discounts</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__ animate__fadeInUp animated"
                            data-wow-delay=".4s"
                            style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-5.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Easy returns</h3>
                                <p>Within 30 days</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6 d-xl-none">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp animated"
                            data-wow-delay=".5s"
                            style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
                            <div class="banner-icon"><img src="../../../assets/shop/imgs/theme/icons/icon-6.svg" alt=""></div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Safe delivery</h3>
                                <p>Within 30 days</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-padding footer-mid">
            <div class="container pt-15 pb-20">
                <div class="row">
                    <div class="col">
                        <div class="widget-about font-md mb-md-3 mb-lg-3 mb-xl-0 wow animate__ animate__fadeInUp animated"
                            data-wow-delay="0" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="logo mb-30"><a href="index.html" class="mb-15"><img
                                        src="../../../assets/shop/imgs/theme/flogo.png" alt="logo" style="height:87px;"></a>
                                <p class="font-lg text-heading">Binasta Limited</p>
                            </div>
                            <ul class="contact-infor">
                                <li><img src="../../../assets/shop/imgs/theme/icons/icon-location.svg" alt=""><strong>Address:
                                    </strong> <span>5171 Utawala Nairobi</span></li>
                                <li><img src="../../../assets/shop/imgs/theme/icons/icon-contact.svg" alt=""><strong>Call
                                        Us:</strong><span>(+254) 70124553</span></li>
                                <li><img src="../../../assets/shop/imgs/theme/icons/icon-email-2.svg"
                                        alt=""><strong>Email:</strong><span><a
                                            
                                            class="__cf_email__"
                                            data-cfemail="addeccc1c8ede3c8ded983cec2c0">support@binasta.co.ke</a></span>
                                </li>
                                <li><img src="../../../assets/shop/imgs/theme/icons/icon-clock.svg"
                                        alt=""><strong>Hours:</strong><span>08:00 - 18:00, Mon - Sat</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer-link-widget col wow animate__ animate__fadeInUp animated" data-wow-delay=".1s"
                        style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                        <h4 class="widget-title">Quick Links</h4>
                        <ul class="footer-list mb-sm-5 mb-md-0">
                            <li><Link href="/products" class="">Shop</Link></li>
                            <li><a href="https://binasta.co.ke/terms">Terms &amp; Conditions</a></li>
                            <li><Link href="/contact">Contact Us</Link></li>
                        </ul>
                    </div>
                    <div class="footer-link-widget col wow animate__ animate__fadeInUp animated" data-wow-delay=".2s"
                        style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <h4 class="widget-title">Careers</h4>
                        <ul class="footer-list mb-sm-5 mb-md-0">
                            <li><a href="https://distributor.binasta.co.ke/register">Binasta Distributor</a></li>
                            <li><a href="#">Delivery Services (Coming Soon)</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <div class="container pb-30 wow animate__ animate__fadeInUp animated" data-wow-delay="0"
            style="visibility: visible; animation-name: fadeInUp;">
            <div class="row align-items-center">
                <div class="col-12 mb-30">
                    <div class="footer-bottom"></div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <p class="font-sm mb-0">© 2023, <strong class="text-brand">Binasta Limited</strong>
                        <br>All rights reserved</p>
                </div>
                <div class="col-xl-4 col-lg-6 text-center d-none d-xl-block">
                    <div class="hotline d-lg-inline-flex mr-30"><img src="../../../assets/shop/imgs/theme/icons/phone-call.svg"
                            alt="hotline">
                        <p>(254)19006666<span>Working 8:00 - 22:00</span></p>
                    </div>
                    <div class="hotline d-lg-inline-flex"><img src="../../../assets/shop/imgs/theme/icons/phone-call.svg"
                            alt="hotline">
                        <p>(254)19006666<span>24/7 Support Center</span></p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 text-end d-none d-md-block">
                    <div class="mobile-social-icon">
                        <h6>Follow Us</h6><a href="#"><img src="../../../assets/shop/imgs/theme/icons/icon-facebook-white.svg"
                                alt=""></a><a href="#"><img src="../../../assets/shop/imgs/theme/icons/icon-twitter-white.svg"
                                alt=""></a><a href="#"><img src="../../../assets/shop/imgs/theme/icons/icon-instagram-white.svg"
                                alt=""></a><a href="#"><img src="../../../assets/shop/imgs/theme/icons/icon-pinterest-white.svg"
                                alt=""></a><a href="#"><img src="../../../assets/shop/imgs/theme/icons/icon-youtube-white.svg"
                                alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>
<style>

</style>
