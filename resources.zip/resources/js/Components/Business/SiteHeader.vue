<script setup>
</script>

<template>
    <header class="header" id="header">
        <div class="header-top">
            <div class="wrapper">
                <div class="socials">
                    <div class="footer-title">Find us here:</div>
                    <div class="socials">
                        <div class="socials__item"><a href="#" target="_blank" class="socials__link">Fb</a></div>
                        <div class="socials__item"><a href="#" target="_blank" class="socials__link">Ins</a></div>
                        <div class="socials__item"><a href="#" target="_blank" class="socials__link">In</a></div>
                    </div>
                </div>
                <div class="phone-item footer-phone">
                    <div class="footer-title footer-title_phone">Have a question? Email us!</div>
                    <div class="footer-phone__item"><a href="mailto:info@binasta.co.ke">info@binasta.co.ke</a></div>
                </div>
            </div>
        </div>
        <div class="wrapper">
            <div class="nav-logo"><a href="#mainMenu" class="logo"><img src="/business/img/flogo.png"
                        alt="Binasta Limited - Business"></a></div>
            <div class="header-right">
                <div id="mainNav" class="menu-box">
                    <nav class="nav-inner">
                        <ul class="main-menu js-menu" id="mainMenu">
                            <li><a href="#services" class="current">Services</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="#testimonials">Testimonials</a></li>
                            <li><a href="#blog">Blog</a></li>
                        </ul>
                    </nav>
                    <div class="socials-item">
                        <div class="footer-title">Find us here:</div>
                        <div class="socials">
                            <div class="socials__item"><a href="#" target="_blank" class="socials__link">Fb</a>
                            </div>
                            <div class="socials__item"><a href="#" target="_blank" class="socials__link">Ins</a>
                            </div>
                            <div class="socials__item"><a href="#" target="_blank" class="socials__link">In</a>
                            </div>
                        </div>
                    </div>
                    <div class="phone-item footer-phone">
                        <div class="footer-title footer-title_phone">Have a question? Email us!</div>
                        <div class="footer-phone__item"><a href="mailto:info@binasta.co.ke">info@binasta.co.ke</a>
                        </div>
                    </div>
                </div><a href="https://distributor.binasta.co.ke/register"
                    class="btn-2 btn_started-header js-fancybox">get started</a>
            </div>
            <div class="bars-mob js-button-nav">
                <div class="hamburger"><span></span><span></span><span></span></div>
                <div class="cross"><span></span><span></span></div>
            </div>
        </div>
    </header>
</template>