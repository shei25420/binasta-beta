<script setup>

</script>
<template>
    <footer id="footer" class="footer footer-2">
    <div class="footer__bg lazy" src="../../../assets/shop/imgs/theme/img_loading.gif" data-src="/business/img/bg/footer-2.svg"></div>
    <div class="wrapper"><a href="index.html" class="logo-footer"><img src="/business/img/flogo.png" alt="Numerio"></a>
        <div class="socials-item footer-social">
            <div class="footer-title">Find us here:</div>
            <div class="socials">
                <div class="socials__item"><a href="#" target="_blank" class="socials__link">Fb</a></div>
                <div class="socials__item"><a href="#" target="_blank" class="socials__link">Ins</a></div>
                <div class="socials__item"><a href="#" target="_blank" class="socials__link">In</a></div>
            </div>
        </div>
        <div class="phone-item footer-phone">
            <div class="footer-title footer-title_phone">Have a question? Email us!</div>
            <div class="footer-phone__item"><a href="mailto:info@binasta.co.ke">info@binasta.co.ke</a></div>
        </div><a href="https://distributor.binasta.co.ke/register" class="btn-2 btn_started js-fancybox">get started</a>
    </div>
    <div class="footer-bottom">
        <div class="wrapper">
            <div class="copyrights">© 2022 Binasta Limited</div>
            <div class="footer-menu">
                <ul class="js-menu-footer">
                    <li><a href="#services">Services</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#blog">Blog</a></li>
                    <li><a href="https://binasta.co.ke/terms">Terms &amp; Conditions</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
</template>