<script setup>
    

</script>
    
<template>
    <footer class="content-footer">
        <div>© 2023 Binasta Limited</div>
        <div>
            <nav class="nav gap-4">
                <a href="https://themeforest.net/licenses/standard" class="nav-link">Terms &amp; Conditions</a>
                <a href="#" class="nav-link">Change Log</a>
                <a href="#" class="nav-link">Get Help</a>
            </nav>
        </div>
    </footer>
</template>
<style>

</style>